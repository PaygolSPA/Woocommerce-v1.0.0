<?php

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit();
} ?>

<div class="wc_paygol_payment_method_options">
    <ul>
        <?php foreach ($paymentMethods['methods'] as $paymentOption): ?>
            <li class="payment_method <?php echo 'payment_method_' . esc_attr($this->id) . '_' . esc_attr($paymentOption['code']); ?>">
            <input class="input-radio" id="<?php echo 'payment_option_' .
                esc_attr($this->id) .
                '_' .
                esc_attr($paymentOption['code']); ?>" type="radio" name="paygol_payment_option" value="<?php echo esc_attr(
    $paymentOption['code']
); ?>"/>
                <label for="<?php echo 'payment_option_' . esc_attr($this->id) . '_' . esc_attr($paymentOption['code']); ?>">
                        <?php echo $this->get_icon_option($paymentOption); ?>
                </label>
            </li>
        <?php endforeach; ?>
    </ul>
</div>