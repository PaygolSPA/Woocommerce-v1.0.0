<?php

namespace Paygol\PaygolWoocommerce\includes\payment;

use WC_Order;
use WC_Payment_Gateway;
use Paygol\PaygolCore\PaygolApi;
use Paygol\PaygolCore\Models\Payer;
use Paygol\PaygolCore\Models\RedirectUrls;
use Paygol\PaygolCore\EnvironmentEnum;

// Translation: https://www.flippercode.com/make-a-wordpress-plugin-multilingual/
// https://github.com/vslavik/poedit
class WC_Paygol_Gateway extends WC_Payment_Gateway
{
    const PGID_REQUEST = 'PGID';
    const STATUS_REQUEST = 'status';
    const CUSTOM_REQUEST = 'custom';
    const KEY_REQUEST = 'key';

    const PLUGIN_ID = 'paygol';
    const API_HOOK_PREFIX = 'woocommerce_api_';
    const CONFIRMATION_API_NAME = 'confirmation_' . self::PLUGIN_ID;
    const API_HOOK_CONFIRMATION_KEY = self::API_HOOK_PREFIX . self::CONFIRMATION_API_NAME;

    /** KDU Credentials */
    const DEFAULT_SERVICE_ID = 479051;
    const DEFAULT_SECRET_KEY = 'cae9af83-61d4-11ec-8b6b-02ec38304cd8';

    /* Paygol credentials */
    //const DEFAULT_SERVICE_ID = 477980;
    //const DEFAULT_SECRET_KEY = '8edb5be2-e479-11e9-9c67-128b57940774';

    public $token_service;
    public $token_secret;
    public $environment;

    public $confirmation_url;

    public function __construct()
    {
        $this->id = self::PLUGIN_ID; // Payment gateway plugin ID
        $this->icon = $this->get_icon(); // Icon that will be displayed on checkout page near your gateway name
        $this->has_fields = false; // In case you need a custom credit card form
        $this->method_title = 'Paygol SpA';
        $this->method_description = __(
            'Enable Paygol as a payment method in your ecommerce, improving your sales by allowing you to pay with Transbank, Khipu, Mach and others.',
            'paygol-woocommerce'
        ); // Will be displayed on the options page

        // Options supported by the gateway (subscriptions, refunds, saved payment, etc). This plugin support simple payments only.
        $this->supports = ['products'];

        // Load the settings.
        $this->init_form_fields();
        $this->init_settings();

        // Set plugin variables
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');

        $this->token_service = $this->get_option('token_service');
        $this->token_secret = $this->get_option('token_secret');
        $this->environment = $this->get_option('enviroment');

        // Hook for payment confirmation
        add_action(self::API_HOOK_CONFIRMATION_KEY, [$this, 'api_hook_confirmation']);

        // Get confirmation url
        $this->confirmation_url = WC()->api_request_url(self::CONFIRMATION_API_NAME);
    }

    /**
     * Plugin options
     */
    public function init_form_fields()
    {
        $this->form_fields = [
            'enabled' => [
                'title' => __('Enable/Disable', 'paygol-woocommerce'),
                'type' => 'checkbox',
                'label' => __('Enable Paygol payment method', 'paygol-woocommerce'),
                'default' => 'yes',
            ],
            'enviroment' => [
                'title' => __('Enviroment', 'paygol-woocommerce'),
                'type' => 'select',
                'label' => __('Select Environment', 'paygol-woocommerce'),
                'default' => EnvironmentEnum::DEVELOPMENT,
                'options' => [
                    EnvironmentEnum::PRODUCTION => 'Producción',
                    EnvironmentEnum::DEVELOPMENT => 'Desarrollo',
                ],
            ],
            'title' => [
                'title' => __('Title', 'paygol-woocommerce'),
                'type' => 'text',
                'description' => __('Paygol section title', 'paygol-woocommerce'),
                'default' => __('Paygol SpA.', 'paygol-woocommerce'),
            ],
            'description' => [
                'title' => __('Customer Message', 'paygol-woocommerce'),
                'type' => 'textarea',
                'description' => __('Message that customers will receive when selecting Paygol', 'paygol-woocommerce'),
                'default' => __(
                    'Paygol is a payment method that improving your sales by allowing you to pay with Transbank, Khipu, Mach and others..',
                    'paygol-woocommerce'
                ),
            ],
            'token_service' => [
                'title' => __('Token Service', 'paygol-woocommerce'),
                'type' => 'text',
                'description' => __('Code obtained from https://secure.paygol.com/sign-in', 'paygol-woocommerce'),
                'default' => self::DEFAULT_SERVICE_ID,
            ],
            'token_secret' => [
                'title' => __('Secret Token', 'paygol-woocommerce'),
                'type' => 'text',
                'description' => __('Code obtained from https://secure.paygol.com/sign-in', 'paygol-woocommerce'),
                'default' => self::DEFAULT_SECRET_KEY,
            ],
            'redirect' => [
                'title' => __('Automatic redirection', 'paygol-woocommerce'),
                'type' => 'checkbox',
                'label' => __('Yes / No', 'paygol-woocommerce'),
                'default' => 'yes',
            ],
        ];
    }

    /*
     * We're processing the payments here
     */
    public function process_payment($orderId)
    {
        $paymentOptionSelected = $_POST['paygol_payment_option'];

        // Show a error message if payment method isn't selected
        if (!$paymentOptionSelected) {
            $this->displayError('Payment method provided by Paygol not selected ', 'paygol-woocommerce');

            return [
                'result' => 'error',
            ];
        }

        return $this->generateTransaction($orderId, $paymentOptionSelected);
    }

    private function generateTransaction($orderId, $paymentOptionSelected)
    {
        try {
            // Order info
            $order = wc_get_order($orderId);
            $total = (float) round($order->get_total());
            $shop_country = !empty($order->get_billing_country()) ? $order->get_billing_country() : 'CL';

            // Init Paygol Core
            $paygol = new PaygolApi($this->token_service, $this->token_secret, $this->environment);

            // Redirections info
            $redirectUrls = new RedirectUrls();
            $transaction_completed_url = $this->confirmation_url;
            $transaction_canceled_url = $this->confirmation_url;
            $redirectUrls->setRedirects($transaction_completed_url, $transaction_canceled_url);
            $paygol->setRedirects($redirectUrls);

            // Payer Info
            $payer = new Payer();
            $payer->setFirstName($order->get_billing_first_name());
            $payer->setLastName($order->get_billing_last_name());
            $payer->setEmail($order->get_billing_email());
            $paygol->setPayer($payer);

            // Rest payment info
            $paygol->setCountry($shop_country);
            $paygol->setPrice($total, get_woocommerce_currency());
            $paygol->setPaymentMethod($paymentOptionSelected);
            $paygol->setName('Payment From Paygol');
            $paygol->setCustom($orderId);

            error_log('Send Data: ' . print_r($paygol, 1));
            $response = (object) $paygol->createPayment();
            error_log('Response Data: ' . print_r($response, 1));

            // Selected Payment method url
            if (property_exists((object) $response, 'data')) {
                /**
                 *  Set order with paygol pending payment status
                 */
                $order->update_status('paygol-pending', $response->data['transaction_id']);
                $order->save();
                add_post_meta($orderId, '_paygol_transaction_id', $response->data['transaction_id'], true);
                error_log('Changing order ' . $orderId . ' to Paygol Pending');

                $redirectUrl = $response->data['payment_method_url'];
                return [
                    'result' => 'success',
                    'redirect' => $redirectUrl,
                ];
            } elseif (property_exists((object) $response, 'error')) {
                // Problem to obtain payment method url.
                $err_msg = 'An error occurred while trying pay with selected method:';
                $err_dsc = $response->error['message'];
                $this->displayError($err_msg, $err_dsc);
                return [
                    'result' => 'error',
                ];
            }

            $this->displayError(
                'An error occurred while to redirect the customer to the selected payment method. Please, try again later.'
            );

            return [
                'result' => 'error',
            ];
        } catch (\Throwable $e) {
            error_log($e->getMessage());
            $this->displayError(
                'An error occurred while to redirect the customer to the selected payment method. Please, try again later.'
            );

            return [
                'result' => 'error',
            ];
        }
    }

    private function displayError($message, $description = null)
    {
        $errMsg = '<p>' . $message . '</p>';
        if ($description) {
            $errMsg = $errMsg . '<p>' . $description . '</p>';
        }

        wc_add_notice(__($errMsg, 'paygol-woocommerce'), 'error');
    }

    // Override this method for
    // show all payment methods supported by Paygol
    public function payment_fields()
    {
        // Show Paygol description
        echo wpautop(wp_kses_post($this->description));

        try {
            // Init Paygol Core
            $paygol = new PaygolApi($this->token_service, $this->token_secret, $this->environment);
            $paymentMethods = $paygol->getPaymentMethods('CL');

            if (property_exists((object) $paymentMethods, 'methods')) {
                // Render payment methods
                include plugin_dir_path(__FILE__) . '../../views/show-payments-methods.php';
            }
        } catch (\Throwable $e) {
            error_log($e->getMessage());
            echo '<p class="woocommerce-error">' .
                __('An error occurred while obtaining payment methods from Paygol. Please, try again later.', 'paygol-woocommerce') .
                '</p>';
        }
    }

    // Validate and confirm payment through Paygol.
    public function api_hook_confirmation()
    {
        $paygolTransactionId = $this->sanitize_url_parameter(self::PGID_REQUEST);
        $paygolStatus = $this->sanitize_url_parameter(self::STATUS_REQUEST);
        $orderIdEncoded = $this->sanitize_url_parameter(self::CUSTOM_REQUEST);
        $signature = $this->sanitize_url_parameter(self::KEY_REQUEST);

        // Request string is not valid
        $isValid = $this->validateRequest($paygolTransactionId, $paygolStatus, $orderIdEncoded, $signature);
        if (!$isValid) {
            $this->displayError('An error occurred while validating response from selected payment method. Please contact to seller.');
            wp_safe_redirect(wc_get_page_permalink('shop'));
            exit();
        }

        // Decode Order id
        $orderId = $this->base64_url_decode($orderIdEncoded);

        // Payment with error or was cancelled
        if ($paygolStatus !== 'completed') {
            $this->redirectToErrorPage($orderId);
        }

        // Payment Confirmation
        $this->confirmTransacction($paygolTransactionId, $orderId);
    }

    // Method for request validation, based on the hash computation of part the request string.
    private function validateRequest($paygolTransactionId, $paygolStatus, $orderIdEncoded, $signature)
    {
        // Part of the request to be validated
        $query_string =
            self::PGID_REQUEST .
            '=' .
            $paygolTransactionId .
            '&' .
            self::STATUS_REQUEST .
            '=' .
            $paygolStatus .
            '&' .
            self::CUSTOM_REQUEST .
            '=' .
            $orderIdEncoded;

        // Compute signature for comparision
        $computed_signature = $this->computeSignature($query_string, $this->token_secret);

        // Request is valid if both signatures are equals.
        return $computed_signature === $signature;
    }

    // Method for confirm transaction (payment)
    private function confirmTransacction($paygolTransactionId, $orderId)
    {
        try {
            error_log('Processing Paygol payment ' . $paygolTransactionId . ' for order nº ' . $orderId);

            // Validate payment against Paygol API
            $paygol = new PaygolApi($this->token_service, $this->token_secret, $this->environment);
            $response = $paygol->getPaymentStatus($paygolTransactionId);

            if (property_exists((object) $response, 'payment')) {
                // Successful validation, validate payment status
                if ($response['payment']['status'] === 'completed') {
                    $this->redirectToSuccessPage($orderId);
                } else {
                    // Payment with error status.
                    error_log($response['payment']);
                    $this->redirectToErrorPage($orderId);
                }
            } else {
                // Failed validation
                error_log($response['error']);
                $this->redirectToErrorPage($orderId);
            }
        } catch (Exception $e) {
            error_log($e->getMessage());
            $this->redirectToErrorPage($orderId);
        }
    }

    private function redirectToSuccessPage($orderId)
    {
        // The order is marked as completed
        $order = wc_get_order($orderId);
        $order->set_status('completed', '');
        $order->save();

        wp_redirect($order->get_checkout_order_received_url());
        exit();
    }

    private function redirectToErrorPage($orderId)
    {
        // The order is marked as failed
        $order = wc_get_order($orderId);
        $order->set_status('failed', '');
        $order->save();

        $this->displayError('There is a problem with the selected payment method or it was cancelled. Please contact to seller.');
        wp_safe_redirect($order->get_checkout_payment_url(true));
        exit();
    }

    /**
     * Get Paygol icon
     *
     * @return img tag
     */
    public function get_icon()
    {
        $logo_url = plugins_url('../assets/images/LogoPaygol.png', plugin_dir_path(__FILE__));
        return '<img src="' . $logo_url . '" class="" alt="Paygol SpA. logo." />';
    }

    /**
     * Get Paygol payment option icon
     *
     * @return img tag
     */
    public function get_icon_option($paymentOption)
    {
        $imgTag = $paymentOption['image']
            ? '<img src="' . $paymentOption['image'] . '" alt="' . esc_attr($paymentOption['name']) . '" />'
            : '';
        return apply_filters('woocommerce_gateway_icon', $imgTag, $paymentOption['code']);
    }

    private function base64_url_decode($b64text)
    {
        return base64_decode(strtr($b64text, '._-', '+/='));
    }

    private function computeSignature($msg, $secret)
    {
        return hash_hmac('sha256', $msg, $secret);
    }

    private function sanitize_url_parameter($param)
    {
        return isset($_REQUEST[$param]) ? sanitize_text_field($_REQUEST[$param]) : null;
    }
}
